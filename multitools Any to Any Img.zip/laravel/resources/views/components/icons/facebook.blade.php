<svg class="{{ $class ?? 'w-4 h-4' }}" fill="none" stroke="currentColor" stroke-width="{{ $strokeWidth ?? 1.5 }}"
    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
</svg>
