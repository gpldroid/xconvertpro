<svg class="{{ $class ?? 'w-4 h-4' }}" fill="none" stroke="currentColor" stroke-width="{{ $strokeWidth ?? 1.5 }}" viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
</svg>
